package com.virtusa.day12springhypernatedemo;

import java.time.LocalDate;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.day12springhypernatedemo.dao.interfaces.TopicDao;
import com.virtusa.day12springhypernatedemo.models.Topic;

/**
 * Hello world!
 *
 */
@SuppressWarnings("unused")
public class App {
	public static void main(String[] args) {
		try {
			@SuppressWarnings("resource")
			ApplicationContext context = new ClassPathXmlApplicationContext(
					"com/virtusa/day12springhypernatedemo/resources/application-bean.xml");

			TopicDao topicDao = (TopicDao) context.getBean("topicDao");
			/*
			 * 
			 * //insert Topic topic=(Topic) context.getBean("topic");
			 * topic.setDescription("education"); topic.setDoc(LocalDate.now());
			 * System.out.println("the primary key ="+topicDao.addTopic(topic));
			 * 
			 * //retrive for(Topic topic:topicDao.getAllTopic()) {
			 * System.out.println(topic.getTopicID()+" "+topic.getDescription()+" "+topic.
			 * getDoc()); } //retrive by id
			 * 
			 * @SuppressWarnings("resource") Scanner sc=new Scanner(System.in); int
			 * inputInt=sc.nextInt(); Topic topic=topicDao.getTopicById(inputInt);
			 * System.out.println(topic.getDescription());
			 * 
			 * 
			 * //update by merging Topic topic=(Topic) context.getBean("topic");
			 * topic.setDescription("science"); topic.setDoc(LocalDate.now());
			 * topic.setTopicID(3); Topic updatedTopic =
			 * topicDao.updateTopicByMerging(topic);
			 * System.out.println(updatedTopic.getDescription());
			 * 
			 * 
			 * //update by save or update Topic topic=(Topic) context.getBean("topic");
			 * topic.setDescription("rocket science"); topic.setDoc(LocalDate.now());
			 * topic.setTopicID(3); topicDao.updateTopic(topic);
			 */
			/*
			 * for(Topic topic:topicDao.getAllTopic()) {
			 * System.out.println(topic.getTopicID()+" "+topic.getDescription()+" "+topic.
			 * getDoc()); }
			 * 
			 * topicDao.deleteTopicById(3);
			 * 
			 * for(Topic topic:topicDao.getAllTopic()) {
			 * System.out.println(topic.getTopicID()+" "+topic.getDescription()+" "+topic.
			 * getDoc()); }
			 */
				 

		} catch (Exception e) {
			System.out.print("error" + e.toString());
		}
	}
}
