package com.virtusa.day12springhypernatedemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.day12springhypernatedemo.dao.interfaces.PersonDao;
import com.virtusa.day12springhypernatedemo.models.Admin;
import com.virtusa.day12springhypernatedemo.models.Person;
import com.virtusa.day12springhypernatedemo.models.User;

@SuppressWarnings("unused")
public class PersonApplication {

	public static void main(String[] args) {
		try {
			@SuppressWarnings("resource")
			ApplicationContext context = new ClassPathXmlApplicationContext("com/virtusa/day12springhypernatedemo/resources/application-bean.xml");
			PersonDao personDao=(PersonDao) context.getBean("personDao");
			/*
			 * Admin admin=(Admin) context.getBean("admin"); //User user=(User)
			 * context.getBean("user"); //Person person=(Person) context.getBean("person");
			 * admin.setAddress("chennai"); admin.setMobile(9876543212L);
			 * admin.setName("vicky");
			 * System.out.println("The Primary Key is "+personDao.addPerson(admin));
			 */
		
		
		}
		catch(Exception e) {
			System.out.println(e.toString());
		}
	}

}
