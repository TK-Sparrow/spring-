package com.virtusa.day12springhypernatedemo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.day12springhypernatedemo.dao.interfaces.CategoryDao;
import com.virtusa.day12springhypernatedemo.models.Category;
import com.virtusa.day12springhypernatedemo.models.Product;

@SuppressWarnings("unused")
public class ProductApplication {

	public static void main(String[] args) {
		try {
			@SuppressWarnings({ "resource" })
			ApplicationContext context = new ClassPathXmlApplicationContext("com/virtusa/day12springhypernatedemo/resources/application-bean.xml");
			/*
			 * Product product1=(Product) context.getBean("product"); Product
			 * product2=(Product) context.getBean("product"); List<Product> productList=new
			 * ArrayList<Product>(); product1.setProductId(102);
			 * product1.setProductName("Laptop"); product1.setDop(LocalDate.of(2018, 7,
			 * 25)); product1.setCost(45000); productList.add(product1);
			 * product2.setProductId(312); product2.setProductName("mobile");
			 * product2.setDop(LocalDate.of(2019, 5, 18)); product2.setCost(22000);
			 * productList.add(product2);
			 * 
			 * Category category=(Category) context.getBean("category");
			 * category.setCategoryId(12); category.setCategoryName("electronic");
			 * category.setProductList(productList);
			 * 
			 * CategoryDao categoryDao=(CategoryDao) context.getBean("categoryDao");
			 * 
			 * System.out.println("The Primary key is "+categoryDao.addCategory(category));
			 */
			
		}
		catch(Exception e) {
			System.out.println(e);
		}

	}

}
