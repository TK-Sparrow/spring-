package com.virtusa.day12springhypernatedemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.day12springhypernatedemo.dao.interfaces.ProductQtyDao;

public class ProductQtyApplication {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		ApplicationContext context = new ClassPathXmlApplicationContext("com/virtusa/day12springhypernatedemo/resources/application-bean.xml");
		ProductQtyDao productQtyDao=(ProductQtyDao) context.getBean("productQtyDao");
		
		System.out.println("The Primary Key is "+productQtyDao.addProductQty(102, 11));
		
		
	}

}
