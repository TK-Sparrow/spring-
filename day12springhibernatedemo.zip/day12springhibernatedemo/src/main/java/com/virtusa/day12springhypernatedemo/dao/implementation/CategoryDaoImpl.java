package com.virtusa.day12springhypernatedemo.dao.implementation;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.virtusa.day12springhypernatedemo.dao.interfaces.CategoryDao;
import com.virtusa.day12springhypernatedemo.models.Category;

public class CategoryDaoImpl implements CategoryDao {

	
	private SessionFactory sessionFactory;
	private Session session;
	private Transaction transaction;
	
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public Integer addCategory(Category category) {
		session=this.sessionFactory.openSession();
		transaction= session.beginTransaction();
		Integer integer=(Integer) session.save(category);
		transaction.commit();
		session.close();
		return integer;
	}

}
