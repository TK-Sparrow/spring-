package com.virtusa.day12springhypernatedemo.dao.implementation;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.virtusa.day12springhypernatedemo.dao.interfaces.PersonDao;
import com.virtusa.day12springhypernatedemo.models.Person;

public class PersonDaoImpl implements PersonDao {
	
	private SessionFactory sessionFactory;
	private Session session;
	private Transaction transaction;
	
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public Long addPerson(Person person) {
		Long primaryKey = null;
		try {
		session=this.sessionFactory.openSession();
		transaction= session.beginTransaction();
		primaryKey=(Long) session.save(person);
		transaction.commit();
		}
		catch(Exception e) {
			transaction.rollback();
		}
		finally {
			session.close();
		}
		return primaryKey;
	}

}
