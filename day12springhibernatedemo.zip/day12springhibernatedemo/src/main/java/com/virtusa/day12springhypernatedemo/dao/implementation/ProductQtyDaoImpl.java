package com.virtusa.day12springhypernatedemo.dao.implementation;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.day12springhypernatedemo.dao.interfaces.ProductQtyDao;
import com.virtusa.day12springhypernatedemo.models.Product;
import com.virtusa.day12springhypernatedemo.models.ProductQty;

public class ProductQtyDaoImpl implements ProductQtyDao {
	
	private SessionFactory sessionFactory;	
	private Session session;
	private Transaction transaction;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	@Override
	public int addProductQty(int productId,int qty) {
		int primaryKey = 0;
		Product product=null;
		ProductQty previousProduct=null;
		ProductQty productQty=null;
		@SuppressWarnings("resource")
		ApplicationContext context = new ClassPathXmlApplicationContext("com/virtusa/day12springhypernatedemo/resources/application-bean.xml");
		productQty=(ProductQty) context.getBean("productQty");
		try {
		session=this.sessionFactory.openSession();
		product=this.session.get(Product.class,productId);
		previousProduct=this.session.get(ProductQty.class,productId);
		if(previousProduct==null) {
			productQty=(ProductQty) context.getBean("productQty");
			productQty.setProduct(product);
			productQty.setPurchaseQty(qty);
			productQty.setAmount(product.getCost()*qty);
			transaction= session.beginTransaction();
			primaryKey=(int) session.save(productQty);
			System.out.println("new");
		}
		else {
			productQty=(ProductQty) context.getBean("productQty");
			int newqty=qty+previousProduct.getPurchaseQty();
			productQty.setPurchaseQty(newqty);
			productQty.setAmount(product.getCost()*newqty);
			transaction= session.beginTransaction();
			System.out.println("update "+newqty);
			session.saveOrUpdate(productQty);
			System.out.println("update "+newqty);
		}
		
		transaction.commit();
		}
		catch(Exception e) {
			transaction.rollback();
		}
		finally {
			session.close();
		}
		return primaryKey;
		
	}

}
