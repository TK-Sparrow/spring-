package com.virtusa.day12springhypernatedemo.dao.implementation;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import com.virtusa.day12springhypernatedemo.dao.interfaces.TopicDao;
import com.virtusa.day12springhypernatedemo.models.Topic;

public class TopicDaoImpl implements TopicDao {
	
	private SessionFactory sessionFactory;
	private Session session;
	private Transaction transaction;
	
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public Integer addTopic(Topic topic) {
		session=this.sessionFactory.openSession();
		transaction= session.beginTransaction();
		Integer integer=(Integer) session.save(topic);
		transaction.commit();
		session.close();
		return integer;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Topic> getAllTopic() {
		session=this.sessionFactory.openSession();
		return session.createQuery(" select topic from Topic topic").getResultList();	
		}

	@Override
	public Topic getTopicById(int id) {
		session=this.sessionFactory.openSession();
		return session.get(Topic.class, id);
	}

	@Override
	public Topic deleteTopicById(int id) {
		
		try {
		session=this.sessionFactory.openSession();
		Topic topic =session.get(Topic.class, id);
		transaction = session.beginTransaction();
		session.delete(topic);
		transaction.commit();
		}
		catch(Exception e) {
			transaction.rollback();
		}
		finally {
			session.close();
		}
		
		return null;
	}

	@Override
	public Topic updateTopicByMerging(Topic topic) {
		session=this.sessionFactory.openSession();
		Topic oldTopic =session.get(Topic.class, topic.getTopicID());
		session.close();
		
		oldTopic.setDescription(topic.getDescription());
		oldTopic.setDoc(topic.getDoc());
		
		session=this.sessionFactory.openSession();
		transaction = session.beginTransaction();
		Topic retTopic = (Topic) session.merge(oldTopic);
		transaction.commit();
		//Topic retTopic = session.get(Topic.class,topic.getTopicID());
		session.close();
		return retTopic;
	}

	@Override
	public Topic updateTopic(Topic topic) {
		session=this.sessionFactory.openSession();
		transaction = session.beginTransaction();
		session.saveOrUpdate(topic);
		transaction.commit();
		session.close();
		return null;
	}

}
