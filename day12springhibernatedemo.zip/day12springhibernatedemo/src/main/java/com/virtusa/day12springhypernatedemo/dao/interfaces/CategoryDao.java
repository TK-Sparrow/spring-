package com.virtusa.day12springhypernatedemo.dao.interfaces;

import com.virtusa.day12springhypernatedemo.models.Category;

public interface CategoryDao {
	
	Integer addCategory(Category category);

}
