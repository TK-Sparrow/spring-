package com.virtusa.day12springhypernatedemo.dao.interfaces;

import com.virtusa.day12springhypernatedemo.models.Person;

public interface PersonDao {
	
	Long addPerson(Person person);

}
