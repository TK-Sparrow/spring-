package com.virtusa.day12springhypernatedemo.dao.interfaces;

public interface ProductQtyDao {
	
	int addProductQty(int productId,int qty);

}
