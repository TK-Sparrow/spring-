package com.virtusa.day12springhypernatedemo.dao.interfaces;

import java.util.List;

import com.virtusa.day12springhypernatedemo.models.Topic;

public interface TopicDao {
		
	Integer addTopic(Topic topic);
	List<Topic> getAllTopic();
	Topic getTopicById(int id);
	Topic deleteTopicById(int id);
	Topic updateTopic(Topic topic);
	Topic updateTopicByMerging(Topic topic);
	
}
