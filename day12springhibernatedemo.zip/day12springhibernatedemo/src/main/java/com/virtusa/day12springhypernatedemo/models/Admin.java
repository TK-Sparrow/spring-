package com.virtusa.day12springhypernatedemo.models;

public class Admin extends Person {
	
	private boolean grantPrivilege;

	public boolean isGrantPrivilege() {
		return grantPrivilege;
	}

	public void setGrantPrivilege(boolean grantPrivilege) {
		this.grantPrivilege = grantPrivilege;
	}
	
	

}
