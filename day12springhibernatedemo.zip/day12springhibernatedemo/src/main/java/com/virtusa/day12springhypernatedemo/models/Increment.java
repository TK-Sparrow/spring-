package com.virtusa.day12springhypernatedemo.models;

public class Increment {
		private int id=0;
		private String message;
		
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getMessage() {
			return message;
		}
		public void setMessage(String message) {
			this.message = message;
		}
}
