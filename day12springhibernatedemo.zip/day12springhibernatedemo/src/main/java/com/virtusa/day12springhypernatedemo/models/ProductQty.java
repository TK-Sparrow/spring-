package com.virtusa.day12springhypernatedemo.models;

public class ProductQty {
		
	private int productQtyId;
	private Product product;
	private long amount;
	private int purchaseQty;
	public int getProductQtyId() {
		return productQtyId;
	}
	public void setProductQtyId(int productQtyId) {
		this.productQtyId = productQtyId;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public long getAmount() {
		return amount;
	}
	public void setAmount(long amount) {
		this.amount = amount;
	}
	public int getPurchaseQty() {
		return purchaseQty;
	}
	public void setPurchaseQty(int purchaseQty) {
		this.purchaseQty = purchaseQty;
	}
}
