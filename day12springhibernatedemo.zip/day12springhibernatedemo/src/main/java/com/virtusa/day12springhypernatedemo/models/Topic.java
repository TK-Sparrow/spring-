package com.virtusa.day12springhypernatedemo.models;

import java.time.LocalDate;

public class Topic {
	
	private int topicID;
	private String description;
	private LocalDate doc;
	
	public int getTopicID() {
		return topicID;
	}
	public void setTopicID(int topicID) {
		this.topicID = topicID;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public LocalDate getDoc() {
		return doc;
	}
	public void setDoc(LocalDate doc) {
		this.doc = doc;
	}

}
