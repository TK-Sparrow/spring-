package com.virtusa.day12springhypernatedemo.models;

public class User extends Person {
		
		private boolean LimitedAccess;

		public boolean isLimitedAccess() {
			return LimitedAccess;
		}

		public void setLimitedAccess(boolean limitedAccess) {
			LimitedAccess = limitedAccess;
		}
		
}
