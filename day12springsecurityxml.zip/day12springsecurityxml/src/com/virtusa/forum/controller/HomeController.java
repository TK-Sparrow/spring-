package com.virtusa.forum.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {
	@GetMapping("/")
	public String home() {
		
		return "home";
	}
	
	@GetMapping("/positive")
	public String positive() {
		return "positive";
	}
	
	@GetMapping("/login")
	public String login() {
		return "login";
	}
	
	@GetMapping("/userhome")
	public String userhome() {
		return "userhome";
	}
	
	@GetMapping("/adminhome")
	public String adminhome() {
		return "adminhome";
	}
}
