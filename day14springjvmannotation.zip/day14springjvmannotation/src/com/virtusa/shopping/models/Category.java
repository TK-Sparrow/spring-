package com.virtusa.shopping.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Day14Category")
public class Category {
			
	@Id
	@Column(name="categoryId")
	@GeneratedValue(generator="category_seq",strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(sequenceName="category_seq",name="category_seq")
	private int categoryId;

	@Column(name="categoryName",nullable=false,length=50)
	private String categoryName;
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	
}
