package com.virtusa.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.ecommerce.models.Customer;
import com.virtusa.ecommerce.services.CustomerServices;

@RestController
public class CustomController {
	
	@Autowired
	private CustomerServices customerService;
	
	@CrossOrigin("*")
	@PostMapping("/addcustomer")
	public @ResponseBody Customer addCustomer(@RequestBody Customer customer) {
		return customerService.SaveCustomer(customer);
		
	}

	@CrossOrigin("*")
	@GetMapping("/getcustomer")
	public List<Customer> findAllCustomer(){
		return customerService.getAllUser();
	}

	@CrossOrigin("*")
	@GetMapping("/getcustomerbyid/{customerId}")
	public Customer findByCustomerId(@PathVariable("customerId") int customerId) {
		return customerService.getCustomerById(customerId);
	}

}
