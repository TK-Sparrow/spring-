package com.virtusa.ecommerce.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.ecommerce.models.Customer;
import com.virtusa.ecommerce.repository.CustomerRepository;

@Service
public class CustomerServices {
	
	@Autowired
	private CustomerRepository customerRepository;
	
	public Customer SaveCustomer(Customer customer) {
		return customerRepository.save(customer);
		
	}
	
	public List<Customer> getAllUser(){
		return customerRepository.findAll();
		
	}
	
	public Customer getCustomerById(int customerId) {
		return customerRepository.findById(customerId).orElse(null);
		
	}

}
