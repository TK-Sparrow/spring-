package com.virtusa.selenuimsuite;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

/**test web driver
 *
 */
public class App 

{

public static void readExcel(String filePath,String fileName,String sheetName) throws IOException{
	File file=new File(filePath+"\\"+fileName);
	
	FileInputStream inputStream=new FileInputStream(file);
	
	Workbook workBook=null;
	
	String fileExtensionName=fileName.substring(fileName.indexOf("."));
	
	if(fileExtensionName.equals(".xlsx")) {
		workBook = new XSSFWorkbook(inputStream);
	}
	else if(fileExtensionName.equals(".xls")) {
		workBook = new HSSFWorkbook(inputStream);
	}
	
	Sheet sheet=workBook.getSheet(sheetName);
	
	int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();
	
	for(int i=0;i<rowCount+1;i++) {
		Row row=sheet.getRow(i);
		
		for(int j=0;j<row.getLastCellNum();j++) {
			if(row.getCell(j).getCellType().equals(CellType.STRING)) {
				System.out.print(row.getCell(j).getStringCellValue()+" || ");
			}
			else if((HSSFDateUtil.isCellDateFormatted(row.getCell(j)))) {
				System.out.print(row.getCell(j).getDateCellValue()+" || ");
			}
			else if(row.getCell(j).getCellType().equals(CellType.NUMERIC)) {
				System.out.print(row.getCell(j).getNumericCellValue()+" || ");
			}
			
			
		}
		System.out.println();
		
	}
	
}

    public static void main( String[] args ) throws InterruptedException, IOException
    {
    	
    	
    	readExcel("C:\\Users\\CSS\\Desktop","testcase.xlsx","Sheet1");    	
        System.setProperty("webdriver.chrome.driver","E:\\chromedriver.exe");
        
        WebDriver webDriver=new ChromeDriver();
        webDriver.get("http://localhost:7070/day14springmvcjpashopping");
        
        
        webDriver.findElement(By.id("username")).sendKeys("admin");
        webDriver.findElement(By.id("password")).sendKeys("admin");
        webDriver.findElement(By.xpath("/html/body/section[2]/form/fieldset/button")).click();
        webDriver.findElement(By.xpath("/html/body/section/header/article/div[2]/button")).click();
        webDriver.findElement(By.xpath("/html/body/section/header/article/div[2]/div/a[1]")).click();
        webDriver.findElement(By.name("productName")).sendKeys("watch");
        webDriver.findElement(By.name("cost")).sendKeys("2000");
        webDriver.findElement(By.name("dop")).sendKeys("03-10-2018");
        
        Select drpDown=new Select(webDriver.findElement(By.name("categoryInfo")));
        drpDown.selectByVisibleText("8712-mobile");
        
        webDriver.findElement(By.xpath("/html/body/form/fieldset/button[1]")).click();
        //categoryName
       // webDriver.wait(200);
        //webDriver.close();
        
        System.out.println("hello");
    }
}
