package com.virtusa.vrps;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VrpsApplication {

	public static void main(String[] args) {
		SpringApplication.run(VrpsApplication.class, args);
		
		
		
		
		
	}

}

