package com.virtusa.vrps.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.virtusa.vrps.models.Education;
import com.virtusa.vrps.models.Job;
import com.virtusa.vrps.models.Personal;
import com.virtusa.vrps.models.Work;
import com.virtusa.vrps.services.ApplicationService;
import com.virtusa.vrps.services.CompanyService;
import com.virtusa.vrps.services.EducationService;
import com.virtusa.vrps.services.JobService;
import com.virtusa.vrps.services.PersonalService;
import com.virtusa.vrps.services.WorkService;

@Controller
public class AdminController {
	
	@Autowired
	private PersonalService personalService;
	
	@Autowired
	private EducationService educationService;
	
	@Autowired
	private CompanyService companyService;
	
	@Autowired
	private WorkService workService;
	
	@Autowired
	private ApplicationService applicationService;
	
	@ModelAttribute("personalDetails")
	public List<Personal> getAllPersonalDetails(){
		return personalService.getAllPersonal();
	}
	
	
	@GetMapping("/selected")
	public String selected() {
		int employeeId=1234;
		String role="ROLE_ADMIN";
		applicationService.updateStatus(employeeId, role, 1);
		return "viewcandidate";
	}
	
	@GetMapping("/rejected")
	public String rejected() {
		int employeeId=1234;
		String role="ROLE_ADMIN";
		applicationService.updateStatus(employeeId, role, 2);
		return "viewcandidate";
	}
	
	@GetMapping("/viewcandidate")
	public String employeeList(Model model) {
		String Role="ADMIN";
		model.addAttribute("workDetails",workService.customeFindAllWorkDetails(Role));
		return "viewcandidate";
	}
	
	@GetMapping("/viewselectedcandidate")
	public String selectedemployeeList(Model model) {
		String Role="ADMIN";
		model.addAttribute("workDetails", workService.customeFindSelectedWorkDetails(Role));
		return "viewcandidate";
	}
	
	
	
	@GetMapping( "/viewemployeedetail")
	public String abcd(@RequestParam("id") String id,Model model) {
		System.out.println("id:"+id);
		int employeeId = Integer.parseInt(id);
		model.addAttribute("personal", personalService.getPersoalById(employeeId));
		model.addAttribute("educations", educationService.getEducationkById(employeeId));
		model.addAttribute("work", workService.getWorkById(employeeId));
		model.addAttribute("companies", companyService.getApplicationById(workService.getWorkById(employeeId).getWorkId()));
		
		return "viewemployeedetail";
	}
	
}
