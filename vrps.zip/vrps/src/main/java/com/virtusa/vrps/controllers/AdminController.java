package com.virtusa.vrps.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.virtusa.vrps.models.Education;
import com.virtusa.vrps.models.Job;
import com.virtusa.vrps.models.Personal;
import com.virtusa.vrps.models.Work;
import com.virtusa.vrps.services.EducationService;
import com.virtusa.vrps.services.JobService;
import com.virtusa.vrps.services.PersonalService;
import com.virtusa.vrps.services.WorkService;

@Controller
public class AdminController {
	
	@Autowired
	private PersonalService personalService;
	
	@Autowired
	private EducationService educationService;
	
	@Autowired
	private JobService jobService;
	
	@Autowired
	private WorkService workService;
	
	@ModelAttribute("personalDetails")
	public List<Personal> getAllPersonalDetails(){
		return personalService.getAllPersonal();
	}
	
	@ModelAttribute("educationDetails")
	public List<Education> getAllEducationDetails(){
		return educationService.findAllEducationDetails();
	}
	@ModelAttribute("jobDetails")
	public List<Job> getAllJobDetails(){
		return jobService.findAllJobDetails();
	}
	@ModelAttribute("workDetails")
	public List<Work> getAllWorkDetails(){
		return workService.findAllWorkDetails();
	}
	
	@GetMapping("/employeeList")
	public String employeeList() {
		return "employeeList";
	}

}
