package com.virtusa.vrps.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.virtusa.vrps.models.Education;
import com.virtusa.vrps.models.Job;
import com.virtusa.vrps.models.Personal;
import com.virtusa.vrps.models.Work;
import com.virtusa.vrps.services.EducationService;
import com.virtusa.vrps.services.JobService;
import com.virtusa.vrps.services.PersonalService;
import com.virtusa.vrps.services.WorkService;

@Controller
public class AdminController {
	
	@Autowired
	private PersonalService personalService;
	
	@Autowired
	private EducationService educationService;
	
	@Autowired
	private JobService jobService;
	
	@Autowired
	private WorkService workService;
	
	@ModelAttribute("personalDetails")
	public List<Personal> getAllPersonalDetails(){
		return personalService.getAllPersonal();
	}
	
	@ModelAttribute("educationDetails")
	public List<Education> getAllEducationDetails(){
		return educationService.findAllEducationDetails();
	}
	@ModelAttribute("jobDetails")
	public List<Job> getAllJobDetails(){
		return jobService.findAllJobDetails();
	}
	@ModelAttribute("workDetails")
	public List<Work> getAllWorkDetails(){
		List<Work> works=workService.findAllWorkDetails();
		for(Work w:works) {
			System.out.println("work:"+w.getLocation());
		}
		return workService.findAllWorkDetails();
	}
	
	@GetMapping("/viewcandidate")
	public String employeeList() {
		return "viewcandidate";
	}
	
	@GetMapping( "/viewemployee")
	public String viewemployee(@RequestParam("id") String id) {
		System.out.println("id:"+id);
		return "viewemployee";
	}
	
	@GetMapping( "/abcd")
	public String abcd(@RequestParam("id") String id) {
		System.out.println("id:"+id);
		return "home";
	}

}
