package com.virtusa.vrps.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.virtusa.vrps.models.Application;
import com.virtusa.vrps.models.Company;
import com.virtusa.vrps.models.Education;
import com.virtusa.vrps.models.Employee;
import com.virtusa.vrps.models.Personal;
import com.virtusa.vrps.models.Work;
import com.virtusa.vrps.services.ApplicationService;
import com.virtusa.vrps.services.CompanyService;
import com.virtusa.vrps.services.EducationService;
import com.virtusa.vrps.services.EmployeeService;
import com.virtusa.vrps.services.PersonalService;
import com.virtusa.vrps.services.WorkService;


@Controller
public class EmployeeDetails {
	@Autowired
	private PersonalService personalService;
	
	@Autowired
	private EmployeeService employeeService;
	
	@Autowired
	private EducationService educationService;
	
	@Autowired
	private WorkService workService;
	
	@Autowired
	private CompanyService companyService;
	
	@Autowired
	private ApplicationService applicationService;
	
	@PostMapping("/addpersonal")
	public String savepersonal(@ModelAttribute Personal personal,Model model)
	{	
		Employee employee=employeeService.getEmployee(1234);
		
		  personal.setEmployee(employee); 
		  System.out.println("employee="+employee);
		  personalService.savePersonal(personal);
		 
		
		Application application=new Application();
		application.setAdminStatus(0);
		application.setHrStatus(0);
		application.setTrStatus(0);
		application.setEmployee(employee);
		application.setReferenceId(3432);
		applicationService.saveApplication(application);
		return "education";	
	}
	
	@PostMapping("/addeducation")
	public String saveEducation(@ModelAttribute Education education,Model model)
	{	
		Employee employee=employeeService.getEmployee(1234);
		
			System.out.println("education="+education.getInstitutionName());
			education.setEmployee(employee);
			educationService.saveEducation(education);
		return "education";	
	}
	
	@PostMapping("addwork")
	public String saveJob(@ModelAttribute Work work,Model model)
	{	
		Employee employee=employeeService.getEmployee(1234);
			work.setEmployee(employee);
			System.out.println();
			workService.saveWork(work);
		return "work";	
	}
	
	@PostMapping("addcompany")
	public String saveCompany(@ModelAttribute Company company,Model model)
	{	
		
		Work work=workService.getWorkById(1234);
			company.setWork(work);
			companyService.saveCompany(company);
		return "company";	
	}
}
