package com.virtusa.vrps.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.virtusa.vrps.models.Education;
import com.virtusa.vrps.models.Employee;
import com.virtusa.vrps.models.Personal;
import com.virtusa.vrps.services.EducationService;
import com.virtusa.vrps.services.EmployeeService;
import com.virtusa.vrps.services.PersonalService;


@Controller
public class EmployeeDetails {
	@Autowired
	private PersonalService personalService;
	
	@Autowired
	private EmployeeService employeeService;
	
	@Autowired
	private EducationService educationService;
	
	@PostMapping("/addpersonal")
	public String savepersonal(@ModelAttribute Personal personal,Model model)
	{	
		Employee employee=employeeService.getEmployee(1234);
		personal.setEmployee(employee);
		System.out.println("employee="+employee);
		personalService.savePersonal(personal);
		return "education";	
	}
	
	@PostMapping("/addeducation")
	public String saveEducation(@ModelAttribute List<Education> allEducation,Model model)
	{	
		Employee employee=employeeService.getEmployee(1234);
		for(Education education:allEducation) {
			System.out.println("education="+education.getInstitutionName());
			education.setEmployee(employee);
			educationService.saveEducation(education);
		}
		
		return "education";	
	}
}
