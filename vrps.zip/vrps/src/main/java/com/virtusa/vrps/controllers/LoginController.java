package com.virtusa.vrps.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.virtusa.vrps.models.Person;
import com.virtusa.vrps.services.PersonService;

@Controller
public class LoginController {
	
	/*
	 * @Autowired private PersonService personService;
	 * 
	 * @PostMapping("/checkCredential") public String
	 * checkCredentials(@ModelAttribute Person person,Model model) { String
	 * path=null; Person
	 * getPerson=personService.getUserById(person.getEmployeeId());
	 * System.out.println("error "+person.getEmployeeId()+" "+getPerson.
	 * getEmployeeId()); if(person.getPassword().equals(getPerson.getPassword())){
	 * String role = getPerson.getRole(); if(role.equalsIgnoreCase("Employee")) {
	 * path="employeeHome"; } else { path="adminHome"; } } else {
	 * model.addAttribute("error", "Invalid Credentials"); path="login"; }
	 * 
	 * return path; }
	 */
}
