package com.virtusa.vrps.models;

import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "Employee")
@PrimaryKeyJoinColumn
public class Employee extends Person {
	
	
	
}
