
  package com.virtusa.vrps.models;
  
  import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne; 
 import javax.persistence.Table;
  
  @Entity
  
  @Table(name = "RatingAndComments") public class RatingAndComments {
  
  @Id 
  @GeneratedValue(strategy = GenerationType.AUTO)
  private int rACId;
  
  @ManyToOne(cascade = CascadeType.MERGE, fetch = FetchType.LAZY)
  @JoinColumn
  private Employee employee;
  
  @ManyToOne 
  private Admin admin;
  
 
  
  
  private int rating; private String comments;
  
  public int getrACId() { return rACId; }
  
  public void setrACId(int rACId) { this.rACId = rACId; }
  
  
  
  public int getRating() { return rating; }
  
  public void setRating(int rating) { this.rating = rating; }
  
  public String getComments() { return comments; }
  
  public void setComments(String comments) { this.comments = comments; }
  
  public Employee getEmployee() { return employee; }
  
  public void setEmployee(Employee employee) { this.employee = employee; }
  
  public Admin getAdmin() { return admin; }
  
  public void setAdmin(Admin admin) { this.admin = admin; }
  
  
  
  }
 