package com.virtusa.vrps.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.virtusa.vrps.models.Application;

public interface ApplicationRepo extends JpaRepository<Application, Integer>{

	@Query("SELECT ap FROM Application ap WHERE ap.referenceId = :referenceId")
	Application getStatusByRefId(@Param("referenceId") long referenceId);

	@Query("SELECT DISTINCT ap FROM Application ap where ap.employee.employeeId = :employeeId")
	Application getApplicationByEmployeeId(@Param("employeeId") int employeeId);
	
	  
}
