package com.virtusa.vrps.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.virtusa.vrps.models.Company;

public interface CompanyRepo extends JpaRepository<Company, Integer>{
	
	@Query("SELECT pr FROM Company pr WHERE pr.work.workId = :workId")
	List<Company> getUserCompanyByID(@Param("workId") int workId);
	
}
