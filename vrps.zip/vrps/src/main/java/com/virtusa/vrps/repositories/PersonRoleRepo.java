package com.virtusa.vrps.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.vrps.models.PersonRole;

public interface PersonRoleRepo extends JpaRepository<PersonRole, Integer> {

}
