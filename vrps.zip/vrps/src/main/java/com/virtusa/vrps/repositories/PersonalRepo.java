package com.virtusa.vrps.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.virtusa.vrps.models.Personal;

public interface PersonalRepo  extends JpaRepository<Personal, Integer> {
	
	@Query("SELECT pr FROM Personal pr WHERE pr.Employee.employeeId = :employeeid")
	Personal getUserPersonalByID(@Param("employeeid") int employeeid);
}
