package com.virtusa.vrps.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.virtusa.vrps.models.Work;

public interface WorkRepo extends JpaRepository<Work, Integer>{
	
	@Query("SELECT wk FROM Work wk WHERE wk.employee.employeeId = :employeeid")
	Work getUserWorkByID(@Param("employeeid") int employeeid);
	
}
