package com.virtusa.vrps.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PersonRoleService {
	
	@Autowired
	private PersonRoleService personRoleService;

}
