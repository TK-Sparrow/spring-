package com.virtusa.vrps.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.vrps.models.Person;
import com.virtusa.vrps.models.Work;
import com.virtusa.vrps.repositories.PersonRepo;

@Service
public class PersonService {

	@Autowired
	private PersonRepo personRepo;
	
	public Person getUserById(int employeeId) {
		return personRepo.findById(employeeId).orElse(null);
	}
	
	

}
