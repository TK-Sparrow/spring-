package com.virtusa.vrps.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.vrps.models.Personal;
import com.virtusa.vrps.models.Work;
import com.virtusa.vrps.repositories.PersonalRepo;

@Service
public class PersonalService {

	@Autowired
	private PersonalRepo personalRepo;
	
	public Personal savePersonal(Personal personal)
	{
		return personalRepo.save(personal);
	}
	public Personal getPersonal(int personalId)
	{
		return personalRepo.findById(personalId).orElse(null);
	}
	
	public List<Personal> getAllPersonal()
	{
		return personalRepo.findAll();
	}
	
	public  Personal  getPersoalById(int employeeId) {
		return personalRepo.getUserPersonalByID(employeeId);	
	}
}
